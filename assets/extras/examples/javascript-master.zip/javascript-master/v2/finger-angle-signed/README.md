Finger Angle
=====

##Description

The angle between index and middle finger will be measured.  Click on the output to see change the units from degrees to radians.

This work by taking the dot product between two direction vectors: http://en.wikipedia.org/wiki/Dot_product

**NOTE**: Upon running, the demo will show saved Hand Playback Data (via [Leap Playback Plugin](http://leapmotion.github.io/leapjs-plugins/docs/#playback)), until your hands enter the field-of-view. Removing your hands from the field-of-view will restart the canned hand playback.