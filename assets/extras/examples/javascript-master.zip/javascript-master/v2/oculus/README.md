Move lights around a THREE.js VR scene
======================================

Right now, only one light can be controlled.  A few things could be explored next:
 - Manipulate different objects, by focusing the closest one on pinch.
 - For handling close objects in constrained situations, use the mouse to select an object, and the hand to move it.
 <br/>This could be used also to manipulate different aspects of an object independently - such as rotation.


Recording made with the LeapJS [Recorder](http://developer.leapmotion.com/recorder).
