#jQuery gesture
Port of the genius $N Multistroke Recognizer & Protractor.
Factorized and simplified (use Protractor only, force bounded rotation, get rid of classes, etc. ).

##Doc & API

##Usage

##Credits:
###$N Multistroke Recognizer & Protractor
@see http://depts.washington.edu/aimgroup/proj/dollar/ndollar.html

Anthony, L. and Wobbrock, J.O. (2012).
$N-Protractor: A fast and accurate multistroke recognizer.
Proceedings of Graphics Interface (GI '12).
Toronto, Ontario (May 28-30, 2012).
Toronto, Ontario: Canadian Information Processing Society, pp. 117-120.
http://dl.acm.org/citation.cfm?id=2305296

Anthony, L. and Wobbrock, J.O. (2010).
A lightweight multistroke recognizer for user interface prototypes.
Proceedings of Graphics Interface (GI '10).
Ottawa, Ontario (May 31-June 2, 2010).
Toronto, Ontario: Canadian Information Processing Society, pp. 245-252.
http://portal.acm.org/citation.cfm?id=1839214.1839258

###Protractor
@see http://www.yangl.org/pdf/protractor-chi2010.pdf

Li, Y. (2010).
Protractor: A fast and accurate gesture recognizer.
Proceedings of the ACM Conference on Human Factors in Computing Systems (CHI '10).
Atlanta, Georgia (April 10-15, 2010).
New York: ACM Press, pp. 2169-2172.
http://dl.acm.org/citation.cfm?id=1753326.1753654

###jQuery Gesture, Easy to use gesture recognition
@see https://github.com/adriengibrat/jQuery-gesture

Adrien Gibrat. (2012).